# DIJELAJAH DONGGALA
### Penjelajah Digital Cagar Budaya Kota Tua Donggala (FPK 2026)

Aplikasi web interaktif eksplorasi cagar budaya bersejarah Kota Tua Donggala dan Pesisir Banawa, Sulawesi Tengah. Dilengkapi peta interaktif (Leaflet), visual panorama 360° (Pannellum), audio transkripsi sejarah, komparasi linimasa foto kolonial (*time slider*), kuis tantangan, pemandu AI, serta formulir input data objek mandiri (11 kolom).

---

## 🚀 Panduan Upload ke GitHub

### Cara 1: Ekspor Langsung dari Google AI Studio (Paling Praktis)
1. Di halaman **Google AI Studio**, klik menu **Settings** (ikon gerigi di kanan atas) atau tombol **Share**.
2. Pilih opsi **Export to GitHub**.
3. Hubungkan akun GitHub Anda dan pilih/buat nama repositori baru (misalnya: `cagar-budaya-donggala`).
4. Klik **Export** — semua kode otomatis terunggah ke repositori GitHub Anda.

---

### Cara 2: Upload Manual via Git CLI (Terminal / Komputer Lokal)
Jika Anda mengunduh kode sebagai file `.zip` dari menu *Download ZIP*:
1. Ekstrak file zip ke komputer Anda, lalu buka terminal/command prompt di folder tersebut.
2. Inisialisasi repositori git dan buat commit awal:
   ```bash
   git init
   git add .
   git commit -m "feat: inisialisasi aplikasi cagar budaya donggala"
   ```
3. Buat repository baru di [github.com](https://github.com/new).
4. Hubungkan remote repository dan push:
   ```bash
   git branch -M main
   git remote add origin https://github.com/USERNAME-ANDA/NAMA-REPO-ANDA.git
   git push -u origin main
   ```

---

## ⚡ Panduan Deploy ke Vercel

Proyek ini sudah dilengkapi file konfigurasi `vercel.json` dan `api/index.ts` sehingga langsung didukung oleh Vercel.

### Langkah Deploy:
1. Buka [vercel.com](https://vercel.com) dan login menggunakan akun **GitHub** Anda.
2. Klik tombol **"Add New..."** lalu pilih **"Project"**.
3. Pilih repositori GitHub Anda (`cagar-budaya-donggala`) lalu klik **"Import"**.
4. Pada menu konfigurasi proyek:
   - **Framework Preset**: Pilih **Vite** (biasanya terdeteksi otomatis).
   - **Root Directory**: Biarkan `./` (default).
   - **Build Command**: Biarkan default (`npm run build`).
   - **Output Directory**: Biarkan default (`dist`).
5. **Environment Variables** (Sangat Penting):
   - Klik bagian **Environment Variables**.
   - Tambahkan key:
     - `GEMINI_API_KEY` = *[Kunci Gemini API Anda dari Google AI Studio]*
   - *(Opsional jika memakai Firebase)*: `FIREBASE_API_KEY` = *[Kunci Firebase Anda]*
6. Klik tombol **"Deploy"**.
7. Tunggu sekitar 1-2 menit hingga proses build selesai. Web Anda kini resmi online dengan domain gratis dari Vercel (misalnya: `https://cagar-budaya-donggala.vercel.app`)!

---

## 💻 Menjalankan di Komputer Lokal (Localhost)

1. Pastikan telah menginstal **Node.js** (versi 18 ke atas).
2. Install dependensi:
   ```bash
   npm install
   ```
3. Salin file environment:
   ```bash
   cp .env.example .env
   ```
   Lalu isi nilai `GEMINI_API_KEY` di dalam file `.env`.
4. Jalankan aplikasi:
   ```bash
   npm run dev
   ```
5. Buka peramban di `http://localhost:3000`.

---

## 📄 Penggunaan File HTML Mandiri (Offline Tanpa Server)

Aplikasi ini juga menyediakan file HTML mandiri:
- Buka langsung file `cagar-budaya-donggala.html` di browser Anda (klik 2x).
- Semua fitur peta, input data 11 kolom, panorama 360, komparasi linimasa foto, dan kuis dapat berjalan langsung di peramban tanpa perlu server.
